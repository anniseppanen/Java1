
public class City {
	private String name, country;
	private int population;

	public City(String name, int population, String country) {
		this.name = name;
		this.population = population;
		this.country = country;
	}

	public String getName() {
		return name;
	}

	public int getPopulation() {
		return population;
	}

	public String getCountry() {
		return country;
	}
}
